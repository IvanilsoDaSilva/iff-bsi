import entities.ListaEntity;

public class ListaEncadeada {

	public static void main(String[] args) {
		ListaEntity lista = new ListaEntity("teste");
		
		lista.add("Teste1");
		lista.add("Teste2");
		lista.add("Teste3");
		
		System.out.println(lista.findFirst());
		System.out.println(lista.findLast());
		System.out.println(lista.length);
		
		System.out.println(lista.find(0));
		
	}

}
