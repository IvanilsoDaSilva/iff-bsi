package entities;

import Interfaces.ListaInterface;

public class ListaEntity implements ListaInterface {
	// Fields
	private NoEntity InicioLista;
	private NoEntity novoNo;
	static public int length = 0;
	
	// Methods - COnstruct
	public ListaEntity() {
	}
	
	public ListaEntity(String data) {
		this.InicioLista = new NoEntity(data, null);
		this.novoNo = InicioLista;
		length++;
	}
	
	// Methods - Others
	@Override
	public void add(String data) {
		length++;
		NoEntity No = new NoEntity(data, null);
		this.novoNo.setNext(No);
		this.novoNo = No;
		if (InicioLista.getNext() == null) {
			InicioLista.setNext(this.novoNo);
		}
	}

	@Override
	public String find(int index) {
		NoEntity no = this.InicioLista;
		for(int i = 0; i < index; i++) {
			no = no.getNext();
		}
		return no.getData();
	}

	@Override
	public void delete(int index) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(int index, String data) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String findFirst() {
		return this.InicioLista.getData();
	}

	@Override
	public String findLast() {
		return this.novoNo.getData();
	}
	
//	public String toString() {
//		
//	}
}
