package entities;

public class NoEntity {
	// Fields
	private NoEntity next;
	private String data;
	
	// Methods - Construct
	public NoEntity() {
	}
	
	public NoEntity(String data, NoEntity next) {
		this.data = data;
		this.next = next;
	}
	
	// Methods - Setters and Getters
	public NoEntity getNext() {
		return next;
	}
	public void setNext(NoEntity next) {
		this.next = next;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	// Methods - toString
	public String toString() {
		return this.data;
	}
}
