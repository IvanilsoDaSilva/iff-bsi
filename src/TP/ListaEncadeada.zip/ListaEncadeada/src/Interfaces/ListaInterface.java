package Interfaces;

public interface ListaInterface {
	public void add(String data);
	public String find(int index);
	public void delete(int index);
	public void update(int index, String data);
	
	public String findFirst();
	public String findLast();
}
